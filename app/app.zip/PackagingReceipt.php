<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PackagingReceipt extends Model
{
    protected $table = 'packaging_receipts';
    protected $guarded  = ['id'];

}
