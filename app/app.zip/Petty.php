<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Petty extends Model
{
    protected $table = 'petty_cash';
    protected $guarded  = ['id'];

  
}
