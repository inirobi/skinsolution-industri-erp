<?php
namespace Carbon;

class Carbon extends \DateTime
{
    // code here
}