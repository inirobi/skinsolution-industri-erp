<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sample_stocks extends Model
{
    //
}
